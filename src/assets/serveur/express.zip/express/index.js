// PACKAGES
// =============================================================================
    var express = require('express');
    var bodyParser = require('body-parser');
    var MongoClient = require('mongodb').MongoClient;
    var assert = require('assert');
    var cors = require('cors');
// =============================================================================

// CONFIG
// =============================================================================
    var config = {
        'port':process.env.PORT || 8080,
        'cors': { // CORS Options
            'origin': '*',
            'optionsSuccessStatus': 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
        },
        'database': {
            'url': 'mongodb://localhost:27017',
            'name': 'nemateria',
            'model': {
                'users': {
                    '_id': -1,
                    'type': 'string',
                    'nom': 'string',
                    'email': 'string',
                    'pass': 'string'
                },
                'medias': {
                    '_id': -1,
                    'type': 'string',
                    'nom': 'string',
                    'description': 'string',
                    'dossier': 'string',
                    'fichier': 'string'
                }
            }
        }
    }
// =============================================================================

// CORE
// =============================================================================
    var app = express();
    var router = express.Router();

    function getModel(modelName) {
        if (config.database.model[modelName] != undefined)
            return config.database.model[modelName];
        else
            return false;        
    }

    function testObject(object, modelName) {
        result = true;
        if (!getModel(modelName))
            result = 'model not found';
        else {
            Object.keys(getModel(modelName)).forEach(function (key) {
                if (object[key] == undefined)
                    result = key + ' not found';
                else {
                    if (typeof object[key] != typeof getModel(modelName)[key])
                        result = key + ' have a wrong type';
                }
            });
        }
        return result;
    }

// =============================================================================

// ROUTER
// =============================================================================
    
    // middleware to use for all requests
    router.use(function (req, res, next) { 
        let message = 'server log: request sent to the server';
        console.log(message);
        next(); // make sure we go to the next routes and don't stop here
    });

    // test route ( GET http://localhost:8080/api)
    router.get('/', function (req, res) { 
        res.json({
            message: 'server log: GET http://localhost:8080/api/'
        });
    });

    // ----------------------------------------------------

    router.route('/users')

        // get all the users (accessed at GET http://localhost:8080/api/users)
        .get(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);
                console.log("server log: GET http://localhost:8080/api/users");

                const db = client.db(config.database.name);
                const collection = db.collection('users');

                collection.find({}).toArray(function (err, docs) {
                    assert.equal(err, null);

                    res.json(docs);

                    client.close();
                });
            });
        })

        // create a user (accessed at POST http://localhost:8080/api/users)
        .post(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);
                console.log("server log: POST http://localhost:8080/api/users");

                const db = client.db(config.database.name);
                const collection = db.collection('users');
                if (testObject(req.body, 'users') != true) {
                    res.status(400);
                    res.json(testObject(req.body, 'users'));
                } else {
                    collection.find({}).toArray(function (err, docs) {
                        assert.equal(err, null);

                        req.body._id = docs.length;

                        collection.insertOne(req.body, function (err, result) {
                            assert.equal(err, null);

                            res.json(result);

                            client.close();
                        });
                    });
                }
            });
        });

    // on routes that end in /users/:user_id
    // ----------------------------------------------------
    router.route('/users/:user_email')

        // get the bear with that id (accessed at GET http://localhost:8080/api/users/:user_id)
        .get(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('users');
                const userEmail = req.params.user_email;

                console.log("server log: GET http://localhost:8080/api/users/" + userEmail);

                collection.find({
                    'email': userEmail
                }).toArray(function (err, docs) {
                    assert.equal(err, null);

                    res.json(docs);

                    client.close();
                });
            });
        })

        // update the user with this id (accessed at PUT http://localhost:8080/api/users/:user_id)
        .put(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('users');
                const updateIndex = parseInt(req.params.user_id);

                if (testObject(req.body, 'users') != true) {
                    res.status(400);
                    res.json(testObject(req.body, 'users'));
                } else {

                console.log("server log: PUT http://localhost:8080/api/users/:" + updateIndex);

                collection.updateOne({
                        "_id": updateIndex
                    }, {
                        $set: {
                            "type": req.body.type,
                            "name": req.body.name,
                            "email": req.body.email,
                            "pass": req.body.pass
                        }
                    }, function (err, result) {
                        assert.equal(err, null);

                        res.json(result);

                        client.close();
                    });
                }
            });
        })

        // delete the user with this id (accessed at DELETE http://localhost:8080/api/users/:user_id)
        .delete(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('users');
                const idDeletedUser = parseInt(req.params.user_id);

                console.log("server log: DELETE http://localhost:8080/api/users/" + idDeletedUser);

                collection.deleteOne({
                    "_id": idDeletedUser
                }, function (err, result) {
                    assert.equal(err, null);

                    res.json(result);

                    client.close();
                });
            });
        });

    // on routes that end in /medias
    // ----------------------------------------------------
    router.route('/medias')

        // get all the medias (accessed at GET http://localhost:8080/api/medias)
        .get(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);
                console.log("server log: GET http://localhost:8080/api/medias");

                const db = client.db(config.database.name);
                const collection = db.collection('medias');

                collection.find({}).toArray(function (err, docs) {
                    assert.equal(err, null);

                    res.json(docs);

                    client.close();
                });
            });
        })

        // create a media (accessed at POST http://localhost:8080/api/medias)
        .post(function (req, res) {
            console.log(req.body);
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);
                console.log("server log: POST http://localhost:8080/api/medias");

                const db = client.db(config.database.name);
                const collection = db.collection('medias');

                if (testObject(req.body, 'medias') != true) {
                    res.status(400);
                    res.json(testObject(req.body, 'medias'));
                } else {

                    collection.find({}).toArray(function (err, docs) {
                        assert.equal(err, null);

                        req.body._id = docs.length;

                        collection.insertOne(req.body, function (err, result) {
                            assert.equal(err, null);

                            res.json(result);

                            client.close();
                        });
                    });
                }
            });
        });

    // on routes that end in /medias/:media_id
    // ----------------------------------------------------
    router.route('/medias/:media_id')

        // get the media with that id (accessed at GET http://localhost:8080/api/medias/:user_id)
        .get(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('medias');
                const idMedia = parseInt(req.params.media_id);

                console.log("server log: GET http://localhost:8080/api/medias/" + idMedia);

                collection.find({
                    '_id': idMedia
                }).toArray(function (err, docs) {
                    assert.equal(err, null);

                    res.json(docs);

                    client.close();
                });
            });
        })

        // update the media with this id (accessed at PUT http://localhost:8080/api/medias/:media_id)
        .put(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('medias');
                const updateIndex = parseInt(req.params.media_id);

                if (testObject(req.body, 'medias') != true) {
                    res.status(400);
                    res.json(testObject(req.body, 'medias'));
                } else {
                    console.log("server log: PUT http://localhost:8080/api/medias/:" + updateIndex);

                    collection.updateOne({
                        "_id": updateIndex
                    }, {
                        $set: {
                            "type": req.body.type,
                            "nom": req.body.nom,
                            "description": req.body.description,
                            "dossier": req.body.dossier,
                            "fichier": req.body.fichier,
                            "updated": req.body.updated,
                        }
                    }, function (err, result) {
                        assert.equal(err, null);

                        res.json(result);

                        client.close();
                    });
                    
                }
            });
        })

        // delete the media with this id (accessed at DELETE http://localhost:8080/api/medias/:media_id)
        .delete(function (req, res) {
            MongoClient.connect(config.database.url, function (err, client) {
                assert.equal(null, err);

                const db = client.db(config.database.name);
                const collection = db.collection('medias');
                const idDeletedMedia = parseInt(req.params.media_id);

                console.log("server log: DELETE http://localhost:8080/api/medias/" + idDeletedMedia);

                collection.deleteOne({
                    "_id": idDeletedMedia
                }, function (err, result) {
                    assert.equal(err, null);

                    res.json(result);

                    client.close();
                });
            });
        });

    // END OF ROUTES -------------------------------
// =============================================================================

// STARTER
// =============================================================================
    app.use(cors(config.cors));
    app.use(bodyParser.json());
    app.use('/api', router);
    app.listen(config.port);
    console.log('server log: server= express; port= ' + config.port);